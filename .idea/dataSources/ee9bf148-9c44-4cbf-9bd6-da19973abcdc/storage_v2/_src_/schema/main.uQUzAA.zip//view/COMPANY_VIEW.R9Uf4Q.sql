CREATE VIEW COMPANY_VIEW AS
SELECT job_id, min(salary) as 'min_sal'
FROM employees
GROUP BY job_id;

