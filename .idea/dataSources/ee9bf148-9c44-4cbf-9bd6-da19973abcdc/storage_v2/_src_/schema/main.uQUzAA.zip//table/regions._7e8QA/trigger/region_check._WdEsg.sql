CREATE TRIGGER region_check AFTER INSERT   
ON regions  
BEGIN  
update regions set region_name='MONE' where region_id=999;
update regions set region_name='MONE_999' where region_id=999;
END;

