# Task1 (частина 2) - відкриття файлу myfile.txt, зчитування та друк його змісту:

with open('myfile.txt') as f:
    print(f.read())